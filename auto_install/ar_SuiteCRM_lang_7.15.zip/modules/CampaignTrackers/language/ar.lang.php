<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SuiteCRM Ltd.
 * Copyright (C) 2011 - 2025 SuiteCRM Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ID' => 'معرف',
    'LBL_TRACKER_KEY' => 'مفتاح المتعقب',
    'LBL_TRACKER_URL' => 'رابط المتعقب',
    'LBL_TRACKER_NAME' => 'اسم المتعقب',
    'LBL_CAMPAIGN_ID' => 'معرف الحملة',
    'LBL_DATE_ENTERED' => 'تاريخ الإدخال',
    'LBL_DATE_MODIFIED' => 'تاريخ التعديل',
    'LBL_MODIFIED_USER_ID' => 'معرف المستخدم المعدل',
    'LBL_CREATED_BY' => 'أنشئ بواسطة',
    'LBL_DELETED' => 'محذوف',
    'LBL_CAMPAIGN' => 'الحملات',
    'LBL_OPTOUT' => 'رفض الاشتراك',

    'LBL_MODULE_NAME' => 'متعقبات الحملات',
    'LBL_EDIT_CAMPAIGN_NAME' => 'اسم الحملة:',
    'LBL_EDIT_TRACKER_NAME' => 'اسم المتعقب:',
    'LBL_EDIT_TRACKER_URL' => 'رابط المتعقب:',

    'LBL_SUBPANEL_TRACKER_NAME' => 'الاسم',
    'LBL_SUBPANEL_TRACKER_URL' => 'الرابط',
    'LBL_SUBPANEL_TRACKER_KEY' => 'المفتاح',
    'LBL_EDIT_MESSAGE_URL' => 'رابط رسالة الحملة:',
    'LBL_EDIT_TRACKER_KEY' => 'مفتاح المتعقب:',
    'LBL_EDIT_OPT_OUT' => 'رابط لرفض الاشتراك؟',
    'LNK_CAMPAIGN_LIST' => 'حملات',
    'LBL_EDIT_LAYOUT' => 'تحرير التصميم' /*for 508 compliance fix*/,
);
