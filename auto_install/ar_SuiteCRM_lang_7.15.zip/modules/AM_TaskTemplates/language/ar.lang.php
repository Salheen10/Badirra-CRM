<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SuiteCRM Ltd.
 * Copyright (C) 2011 - 2025 SuiteCRM Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'معرف المستخدم المُكلف',
    'LBL_ASSIGNED_TO_NAME' => 'أُسند إلى',
    'LBL_ID' => 'المُعرف',
    'LBL_DATE_ENTERED' => 'تاريخ الإنشاء',
    'LBL_DATE_MODIFIED' => 'تاريخ التعديل',
    'LBL_MODIFIED' => 'عُدل بواسطة',
    'LBL_MODIFIED_ID' => 'عدل بواسطة المعرف',
    'LBL_MODIFIED_NAME' => 'قام بالتعديل',
    'LBL_CREATED' => 'أنشئ بواسطة',
    'LBL_CREATED_ID' => 'أنشئ بواسطة المعرف',
    'LBL_DESCRIPTION' => 'الوصف',
    'LBL_DELETED' => 'محذوف',
    'LBL_NAME' => 'اسم المهمة',
    'LBL_CREATED_USER' => 'تم الإنشاء بواسطة المستخدم',
    'LBL_MODIFIED_USER' => 'عُدل بواسطة المستخدم',
    'LBL_LIST_NAME' => 'الاسم',
    'LBL_EDIT_BUTTON' => 'حرر',
    'LBL_REMOVE' => 'إزالة',
    'LBL_LIST_FORM_TITLE' => 'قائمة قوالب مهام المشاريع',
    'LBL_MODULE_NAME' => 'قوالب مهام المشاريع',
    'LBL_MODULE_TITLE' => 'قوالب مهام المشاريع',
    'LBL_HOMEPAGE_TITLE' => 'قوالب مهام المشاريع الخاصة بي',
    'LNK_NEW_RECORD' => 'إنشاء قوالب مهام المشاريع',
    'LNK_LIST' => 'عرض قوالب مهام المشاريع',
    'LNK_IMPORT_AM_TASKTEMPLATES' => 'استيراد قوالب مهام المشاريع',
    'LBL_SEARCH_FORM_TITLE' => 'بحث قوالب مهام المشاريع',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'عرض التاريخ',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'الأنشطة',
    'LBL_AM_TASKTEMPLATES_SUBPANEL_TITLE' => 'قوالب مهام المشروع',
    'LBL_NEW_FORM_TITLE' => 'قوالب مهام مشاريع جديدة',
    'LBL_STATUS' => 'الحالة',
    'LBL_PRIORITY' => 'الأولوية',
    'LBL_PERCENT_COMPLETE' => 'نسبة الإنجاز',
    'LBL_PREDECESSORS' => 'المهام السابقة',
    'LBL_MILESTONE_FLAG' => 'علامة معلم هام',
    'LBL_RELATIONSHIP_TYPE' => 'نوع العلاقة',
    'LBL_TASK_NUMBER' => 'رقم المهمة',
    'LBL_ORDER_NUMBER' => 'الترتيب ',
    'LBL_ESTIMATED_EFFORT' => 'الجهد المقدر (ساعات)',
    'LBL_UTILIZATION' => 'الاستغلال (٪)',
    'LBL_DURATION' => 'المدة (أيام)',
    'LBL_AM_TASKTEMPLATES_AM_PROJECTTEMPLATES_FROM_AM_PROJECTTEMPLATES_TITLE' => 'قوالب المشاريع',

    'LBL_AM_TASKTEMPLATES_AM_PROJECTTEMPLATES_FROM_AM_TASKTEMPLATES_TITLE' => 'قوالب المهام: قوالب المشاريع من عنوان قوالب المهام',
);
