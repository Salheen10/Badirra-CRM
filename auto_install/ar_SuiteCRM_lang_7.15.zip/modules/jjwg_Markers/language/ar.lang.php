<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SuiteCRM Ltd.
 * Copyright (C) 2011 - 2025 SuiteCRM Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings['LBL_ASSIGNED_TO_ID'] = 'معرف المستخدم المُكلف';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'مُستخدم';
$mod_strings['LBL_ID'] = 'المُعرف';
$mod_strings['LBL_DATE_ENTERED'] = 'تاريخ الإنشاء';
$mod_strings['LBL_DATE_MODIFIED'] = 'تاريخ التعديل';
$mod_strings['LBL_MODIFIED'] = 'عُدل بواسطة';
$mod_strings['LBL_MODIFIED_NAME'] = 'قام بالتعديل';
$mod_strings['LBL_CREATED'] = 'أنشئ بواسطة';
$mod_strings['LBL_DESCRIPTION'] = 'الوصف';
$mod_strings['LBL_DELETED'] = 'محذوف';
$mod_strings['LBL_NAME'] = 'الاسم';
$mod_strings['LBL_CREATED_USER'] = 'تم الإنشاء بواسطة المستخدم';
$mod_strings['LBL_MODIFIED_USER'] = 'عُدل بواسطة المستخدم';
$mod_strings['LBL_LIST_NAME'] = 'الاسم';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'قائمة العلامات';
$mod_strings['LBL_MODULE_NAME'] = 'العلامات';
$mod_strings['LBL_MODULE_TITLE'] = 'العلامات';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'علاماتي';
$mod_strings['LNK_NEW_RECORD'] = 'إنشاء علامات';
$mod_strings['LNK_LIST'] = 'عرض العلامات';
$mod_strings['LNK_IMPORT_JJWG_MARKERS'] = 'استيراد العلامات';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'بحث العلامات';
$mod_strings['LBL_HISTORY_SUBPANEL_TITLE'] = 'عرض التاريخ';
$mod_strings['LBL_ACTIVITIES_SUBPANEL_TITLE'] = 'الأنشطة';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'علامات جديدة';
$mod_strings['LBL_CITY'] = 'المدينة';
$mod_strings['LBL_STATE'] = 'المحافظة';
$mod_strings['LBL_COUNTRY'] = 'الدولة';
$mod_strings['LBL_JJWG_MAPS_LAT'] = 'خط العرض';
$mod_strings['LBL_JJWG_MAPS_LNG'] = 'خط الطول';
$mod_strings['LBL_MARKER_IMAGE'] = 'نوع صورة العلامة';
$mod_strings['LBL_LIST_ASSIGNED_USER'] = 'أسند إلى';

$mod_strings['LBL_MARKER_MARKER_POSITION'] = 'موضع العلامة (العرض، الطول):';
$mod_strings['LBL_MARKER_CLOSEST_MATCHING_ADDRESS'] = 'أقرب عنوان مطابق:';
$mod_strings['LBL_MARKER_MARKER_STATUS'] = 'حالة العلامة';
$mod_strings['LBL_MARKER_EDIT_DESCRIPTION'] = 'انقر واسحب العلامة.';
$mod_strings['LBL_JJWG_MAPS_JJWG_MARKERS_FROM_JJWG_MAPS_TITLE'] = 'خرائط';
